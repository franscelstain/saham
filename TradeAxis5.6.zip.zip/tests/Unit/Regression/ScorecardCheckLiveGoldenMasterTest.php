<?php

namespace Tests\Unit\Regression;

use App\DTO\Watchlist\Scorecard\LiveSnapshotDto;
use App\DTO\Watchlist\Scorecard\StrategyRunDto;
use App\Trade\Watchlist\Config\ScorecardConfig;
use App\Trade\Watchlist\Scorecard\ExecutionEligibilityEvaluator;
use App\Trade\Watchlist\Scorecard\ScorecardMetricsCalculator;
use App\Services\Watchlist\WatchlistScorecardService;
use App\Support\SystemClock;
use App\Trade\Watchlist\Scorecard\StrategyRunRepository;
use App\Trade\Watchlist\Scorecard\StrategyCheckRepository;
use App\Trade\Watchlist\Scorecard\ScorecardRepository;
use App\DTO\Watchlist\Scorecard\EligibilityCheckDto;
use App\DTO\Watchlist\Scorecard\ScorecardMetricsDto;
use App\Repositories\TickerOhlcDailyRepository;
use Tests\TestCase;

class ScorecardCheckLiveGoldenMasterTest extends TestCase
{
    public function testGoldenMasterFixtureSnapshotMatchesExpected(): void
    {
        // Be explicit: avoid relying on helper factories across versions.
        $cfg = new ScorecardConfig(false, 0.01, 0.015, 0.004, '09:00', '15:50');
        $clock = new SystemClock();

        $runPayload = json_decode(file_get_contents(__DIR__ . '/../..' . '/Fixtures/scorecard/run_payload.json'), true);
        $snapArr = json_decode(file_get_contents(__DIR__ . '/../..' . '/Fixtures/scorecard/snapshot.json'), true);
        $expected = json_decode(file_get_contents(__DIR__ . '/../..' . '/Fixtures/scorecard/expected_check.json'), true);

        $this->assertIsArray($runPayload);
        $this->assertIsArray($snapArr);
        $this->assertIsArray($expected);

        $runDto = StrategyRunDto::fromPayloadArray($runPayload, 1, $cfg);
        $snapshot = LiveSnapshotDto::fromArray($snapArr, $cfg, $snapArr['checked_at'] ?? '');

        $tradeDate = (string)($runPayload['trade_date'] ?? '');
        $execDate = (string)(($runPayload['exec_trade_date'] ?? '') ?: ($runPayload['exec_date'] ?? ''));
        $policy = (string)(($runPayload['policy']['selected'] ?? '') ?: ($runPayload['policy'] ?? ''));
        $this->assertNotSame('', $tradeDate);
        $this->assertNotSame('', $execDate);
        $this->assertNotSame('', $policy);

        $service = new WatchlistScorecardService(
            // Repos
            new class($cfg, $runDto, $tradeDate, $execDate, $policy) extends StrategyRunRepository {
                private StrategyRunDto $dto;
                private string $tradeDate;
                private string $execDate;
                private string $policy;
                public function __construct(ScorecardConfig $cfg, StrategyRunDto $dto, string $tradeDate, string $execDate, string $policy) {
                    parent::__construct($cfg);
                    $this->dto = $dto;
                    $this->tradeDate = $tradeDate;
                    $this->execDate = $execDate;
                    $this->policy = $policy;
                }
                public function upsertFromDto(StrategyRunDto $dto, string $source = 'watchlist'): int { $this->dto = $dto; return 1; }
                public function getRunDto(string $tradeDate, string $execDate, string $policy, string $source = 'watchlist'): ?StrategyRunDto {
                    if ($tradeDate === $this->tradeDate && $execDate === $this->execDate && $policy === $this->policy) {
                        return $this->dto;
                    }
                    return null;
                }
            },
            new class extends StrategyCheckRepository {
                public function insertCheckFromDto(int $runId, LiveSnapshotDto $snapshot, EligibilityCheckDto $result): int { return 1; }
                public function getLatestCheckDto(int $runId) { return null; }
            },
            new class extends ScorecardRepository {
                public function upsertScorecardFromDto(int $runId, ScorecardMetricsDto $dto): void { /* no-op */ }
            },
            // Evaluator + calculator
            new ExecutionEligibilityEvaluator($cfg),
            new ScorecardMetricsCalculator(),
            // OHLC repo (not needed for check-live)
            new class extends TickerOhlcDailyRepository {
                public function mapOhlcByTickerCodesForDate(string $tradeDate, array $tickerCodes): array { return []; }
            },
            // config + clock
            $cfg,
            $clock
        );

        $dto = $service->checkLiveDto($tradeDate, $execDate, $policy, $snapshot);
        $out = $dto->toArray();

        // Normalize numeric precision for stable diff.
        if (isset($out['results']) && is_array($out['results'])) {
            foreach ($out['results'] as $i => $r) {
                if (isset($r['gap_pct'])) $out['results'][$i]['gap_pct'] = (float)$r['gap_pct'];
                if (isset($r['spread_pct'])) $out['results'][$i]['spread_pct'] = (float)$r['spread_pct'];
                if (isset($r['chase_pct'])) $out['results'][$i]['chase_pct'] = (float)$r['chase_pct'];
            }
        }

        $this->assertSame($expected, $out);
    }
}
